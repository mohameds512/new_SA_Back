<?php

namespace App\Models;


use Illuminate\Database\Eloquent\Model;

class BuildDesc extends Model
{
    protected $guarded = [];
    protected $table = 'building_type_contents';
}

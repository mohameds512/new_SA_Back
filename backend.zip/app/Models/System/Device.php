<?php

namespace App\Models\System;

use Illuminate\Database\Eloquent\Model;

class Device extends Model
{
}

<?php

return [
    'faculties' =>'Faculties',
    'O6U COVID-19 CORONA VIRUS GUIDANCE'=>'O6U COVID-19 CORONA VIRUS GUIDANCE',
    'CORONA VIRUS UPDATES'=>'CORONA VIRUS UPDATES',
    'search'=>'search',
     'OCTOBER 6 UNIVERSITY'=>'OCTOBER 6 UNIVERSITY',
     'PIONEER OF PRIVATE UNIVERSITY EDUCATION IN EGYPT'=>'PIONEER OF PRIVATE UNIVERSITY EDUCATION IN EGYPT',
     'Login'=>'LOGIN',
     'UserName*'=>'UserName*',
     'Password*'=>'Password*',
    'About the College'=>'About The College',
    'artAbout'=>'The Faculty of Applied Arts aims at the development of innovative work in the design field, this
                                will
                                be
                                achieved by
                                continuous research and development in all departments
                                of the faculty.
                                <br/>
                                <br/>
                                The target is to provide the country with specialists in the technical and applied fields through
                                education, training
                                and
                                research in order to participate in community service.
                                <br/>
                                <br/>
                                Take advantage of the sectors of production, services and idustrial enterprises in the training of
                                students to reach the
                                desired level in the field of scientific and vocational training.
                                <br/>
                                <br/>
                                The Faculty aims at the graduation of designers in Applied Arts who would be able to provide designs
                                that would meet the
                                international requirements.
                                <br/>
                                <br/>
                                The educational process is to promote the development of a relationship between art and technology .',
    'APPLY'=>'APPLY',
    'Submission is open'=>'Submission is open',
    'academic calendar'=>'academic calendar',
    'APPLIED ARTS'=>'APPLIED ARTS',
    'PIONEER OF PRIVATE'=>'PIONEER OF PRIVATE',
    'UNIVERSITY EDUCATION IN EGYPT'=>'UNIVERSITY EDUCATION IN EGYPT',
    'ACADEMICS DEPARTMENTS'=>'ACADEMICS DEPARTMENTS',
    'GRADUATE PROGRAMS'=>'GRADUATE PROGRAMS',
    'FACULTY STAFF'=>'FACULTY STAFF',
    "Dean's Message"=>"Dean's Message",
    'DeanWord'=>'The Faculty of Applied Arts contributes to the promotion of human values and
                            taste and to
                            Provide the
                            country with
                            designers and experts equipped with the knowledge and advanced research
                            methods.

                            To reflect the heritage of the Egyptian people, their traditions, and cultural aspects To
                            encourage
                            the
                            investment and
                            development of Human wealth through the development of the innovative mind to
                            meetneeds of society and production centers.',
    'Professor'=>'Professor',
    'Mona Mostafa Abutabl'=>'Mona Mostafa Abutabl',
    'Latest News'=>'Latest News',
    'Keep up-to-date with all the latest O6U news'=>'Keep up-to-date with all the latest O6U news',
    'The Faculty of Applied Arts - October 6 University, sponsored by Prof. Gamal Samy'=>'The Faculty of Applied Arts - October 6 University, sponsored by Prof. Gamal Samy',
    '(University President) and Prof. Mona Abu Tabl (Dean of the College)'=>'(University President) and Prof. Mona Abu Tabl (Dean of the College)',
    'in (the visual image of the Administrative Capital)'=>' in (the visual image of the Administrative Capital',
    'The Community Service Sector'=>'The Community Service Sector at the Faculty of Applied Arts - October 6
                                            University
                                            organized
                                            an exhibition and festival “Africa in the eyes of the international artist”',
    'Media Center'=>'Media Center',
    'Strategic goals and objectives'=>'Strategic goals and objectives',
    'Latest Research'=>'Latest Research',
    'Results'=>'Results',
    'Faculty Policies'=>'Faculty Policies',
    'NEWS'=>'NEWS',
    'DOWNLOADS'=>'DOWNLOADS',
    'Main Links'=>'Main Links',
    'Home'=>'Home',
    'About O6u'=>'About O6u',
    'Library'=>'Library',
    'Hospital'=>'Hospital',
    'Transportation'=>'Transportation',
    'Hotel & Restaurant'=>'Hotel & Restaurant',
    'Archived News'=>'Archived News',
    'Archived Events'=>'Archived Events',
    'Contact Us'=>'Contact Us',
    'Faculty of Engineering'=>'Faculty of Engineering',
    'Faculty of Medicine'=>'Faculty of Medicine',
    'Faculty of Pharmacy'=>'Faculty of Pharmacy',
    'Faculty of Dentistry'=>'Faculty of Dentistry',
    'Faculty of Applied Health'=>'Faculty of Applied Health',
    'Faculty of Physical Therapy'=>'Faculty of Physical Therapy',
    'Faculty of Information'=>'Faculty of Information',
    'Faculty of Applied Arts'=>'Faculty of Applied Arts',
    'Faculty of Media & Mass'=>'Faculty of Media & Mass',
    'Faculty of Economics'=>'Faculty of Economics',
    'Faculty of Education'=>'Faculty of Education',
    'Faculty of Tourism'=>'Faculty of Tourism',
    'Faculty of Nursing'=>'Faculty of Nursing',
    'Postgraduate Studies'=>'Postgraduate Studies',
    'University'=>'University',
    'Address'=>'Address',
    '6th Of October City, Giza Government'=>'6th Of October City, Giza Government',
    'Email'=>'Email',
    'HOTLINE'=>'HOTLINE',
    'About o6u'=>'About o6u',
    'o6u Admission'=>'o6u Admission',
    'Faculties'=>'Faculties',
    'Student'=>'Student',
    'Services'=>'Services',
    'Credit Hours'=>'Credit Hours',
    'T.support'=>'T.support',
    'Keep up-to-date with all the latest O6U news'=>'Keep up-to-date with all the latest O6U news',
    'Prof'=>' Prof. Dr. Ahmed Zaki Badr: Chairman of the follow- up Committee of
    decision implementation of the Supreme Council of Private
    and National Universities',
    'prof_news'=>'  The Supreme Council of Private and National Universities decided to form
    a committee to follow up  the implementation of the council’s decisions.
    The committee is headed by Prof. Dr. Ahmed Zaki Badr, former Minister of Education
    and  Local Development and Chairman of the Board of Trustees of October 6 University and the membership of : Dr. Siddeek Abdel Salam,
    Secretary of the Council of Private and National Universities (member and rapporteur),
    Dr. Ashraf Al Shehhi, President of the Egyptian Chinese University,
    Dr. Ahmed Sameh Farid, President of New Giza University, Dr. Obadah Sarhan, President of the  Future University ,
    Dr. Muhammad Hassan Al Azazi, President of Misr University for Science and Technology, Dr. Yahya Al-Mashad,
     President of Delta University for Science and Technology, Dr. Ahmed Hamad, President of the British University in Egypt, Dr. Mustafa Kamal,
     President of Badr University, Dr. Mohamed Lotif, Secretary of theSupreme Council of Universities.',
     'Read More'=>'Read More',
     'YEARS OF HIGHER'=>'YEARS OF HIGHER',
     'EDUCATION IN EGYPT'=>'EDUCATION IN EGYPT',
     'STUDENTS GRADUATED SINCE 1996'=>'STUDENTS GRADUATED SINCE 1996',
     'ADMISSION'=>'ADMISSION',
     'ADMISSION REQUIREMENTS'=>'ADMISSION REQUIREMENTS',
     'HOW TO APPLY'=>'HOW TO APPLY',
     'SCHOLARSHIPS'=>'SCHOLARSHIPS',
     'SERVICES'=>'SERVICES',
     'video1'=>'The President of October 6 University, talks about
     the national project for reading and sends a message to students',
     'Dr.Gamal Samy'=>'Dr.Gamal Samy',
     'National Reading Programme'=>'National Reading Programme',

    ];

<html>
<head></head>
<body style="margin: 0px; padding: 0px; font-family: Helvetica;">
	<div style="background: black; color: white; padding: 20px; font-size: 52px;font-weight: bold;">EMS</div>
	<div style="padding: 20px; font-size: 28px; font-weight: bold;">Welcome!</div>
	<div style="padding: 0px 20px 0px 20px; font-size: 18px; ">
		<div>Thank you for registering with us.<br/>Please copy the code below to activate your account.</div>
		<p style="font-weight: bold; text-align: center;">Your email activation code is:<p>
		<p style="font-weight: bold; text-align: center; font-size: 24px;"><strong>{{ $data->code }}</strong></p>
	</div>
</body>
</html>
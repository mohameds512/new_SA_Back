<html>
<head></head>
<body style="margin: 0px; padding: 0px; font-family: Helvetica;">
	<div style="background: black; color: white; padding: 20px; font-size: 52px;font-weight: bold;">EMS</div>
	<div style="padding: 20px; font-size: 20px; font-weight: bold;">Dear User,</div>
	<div style="padding: 0px 20px 0px 20px; font-size: 18px; ">
		<div style="font-weight: bold; text-align: center;">Your temprorary password is:</div>
		<div style="font-weight: bold; text-align: center; font-size: 24px;">{{ $data->password }}</div>
		<div>&nbsp;</div>
		<div>If you think that you did not send this request, please ignore this email.</div>
	</div>
</body>
</html>